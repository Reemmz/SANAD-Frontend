import { AppRegistry } from 'react-native';
import ReactNativeYouTubeExample from './ReactNativeYouTubeExample';
import { name as appName } from './app.json';

AppRegistry.registerComponent(appName, () => ReactNativeYouTubeExample);
