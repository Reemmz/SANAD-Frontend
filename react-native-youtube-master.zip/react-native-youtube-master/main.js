import YouTube from './YouTube';
export { YouTubeStandaloneIOS } from './YouTubeStandalone.ios';
export { YouTubeStandaloneAndroid } from './YouTubeStandalone.android';

export default YouTube;
