#import <React/RCTViewManager.h>

@interface RCTYouTubeManager : RCTViewManager

@end
